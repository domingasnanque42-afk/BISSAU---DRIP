package com.bissaudrip.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101010)
private val Gold = Color(0xFFD6AD60)
private val Cream = Color(0xFFF7F4EE)

data class Product(
    val id: Int,
    val name: String,
    val category: String,
    val price: Int,
    val sizes: String,
    val stock: Int
)

data class Order(
    val id: Int,
    val customer: String,
    val phone: String,
    val address: String,
    val items: String,
    val total: Int,
    var status: String = "Pendente"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BissauDripApp() }
    }
}

@Composable
fun BissauDripApp() {
    val products = remember {
        mutableStateListOf(
            Product(1, "T-shirt Drip", "T-shirts", 5000, "S, M, L, XL", 12),
            Product(2, "Hoodie Essential", "Sweatshirts", 12000, "M, L, XL", 7),
            Product(3, "Calças Street", "Calças", 9000, "S, M, L, XL", 5),
            Product(4, "Boné Bissau", "Acessórios", 3500, "Único", 15)
        )
    }
    val cart = remember { mutableStateMapOf<Int, Int>() }
    val orders = remember { mutableStateListOf<Order>() }
    var page by remember { mutableStateOf("Loja") }
    var selected by remember { mutableStateOf<Product?>(null) }
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("T-shirts") }
    var newPrice by remember { mutableStateOf("") }
    var newSizes by remember { mutableStateOf("S, M, L, XL") }
    var notice by remember { mutableStateOf("") }

    val total = products.sumOf { p -> (cart[p.id] ?: 0) * p.price }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Ink, secondary = Gold, background = Cream, surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Cream,
            topBar = {
                Column(
                    Modifier.fillMaxWidth().background(Ink).padding(horizontal = 18.dp, vertical = 16.dp)
                ) {
                    Text("BISSAU DRIP", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("ESTILO DA RUA. IDENTIDADE DE BISSAU.", color = Color.White, fontSize = 10.sp, letterSpacing = 1.2.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Loja", "Carrinho", "Encomendas", "Admin").forEach { tab ->
                        NavigationBarItem(
                            selected = page == tab,
                            onClick = { page = tab; notice = "" },
                            icon = {
                                Text(
                                    when (tab) {
                                        "Loja" -> "⌂"
                                        "Carrinho" -> "🛒"
                                        "Encomendas" -> "📦"
                                        else -> "⚙"
                                    }, fontSize = 18.sp
                                )
                            },
                            label = { Text(if (tab == "Carrinho" && cart.isNotEmpty()) "$tab (${cart.values.sum()})" else tab) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                if (notice.isNotBlank()) {
                    Text(notice, color = Color(0xFF176B39), fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                }
                when (page) {
                    "Loja" -> {
                        Text("PEÇAS EM DESTAQUE", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("Escolhe o teu estilo e adiciona ao carrinho.", color = Color.DarkGray)
                        Spacer(Modifier.height(12.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(products) { p ->
                                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            Modifier.size(74.dp).background(Cream, RoundedCornerShape(12.dp)),
                                            contentAlignment = Alignment.Center
                                        ) { Text("BD", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black) }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(p.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            Text("${p.category} · Tamanhos: ${p.sizes}", fontSize = 11.sp, color = Color.DarkGray)
                                            Text("${p.price} FCFA", color = Ink, fontWeight = FontWeight.Bold)
                                            Text("Stock: ${p.stock}", fontSize = 11.sp, color = Color.Gray)
                                        }
                                        Button(
                                            onClick = {
                                                if ((cart[p.id] ?: 0) < p.stock) {
                                                    cart[p.id] = (cart[p.id] ?: 0) + 1
                                                    notice = "${p.name} adicionado ao carrinho."
                                                } else notice = "Stock insuficiente para ${p.name}."
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Ink),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                                        ) { Text("+ Adicionar", fontSize = 11.sp) }
                                    }
                                }
                            }
                        }
                    }
                    "Carrinho" -> {
                        Text("O TEU CARRINHO", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        if (cart.isEmpty()) Text("Ainda não adicionaste produtos.")
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(products.filter { (cart[it.id] ?: 0) > 0 }) { p ->
                                Card {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(p.name, fontWeight = FontWeight.Bold)
                                            Text("${cart[p.id]} × ${p.price} FCFA")
                                        }
                                        TextButton(onClick = {
                                            val q = cart[p.id] ?: 0
                                            if (q <= 1) cart.remove(p.id) else cart[p.id] = q - 1
                                        }) { Text("−") }
                                        TextButton(onClick = {
                                            if ((cart[p.id] ?: 0) < p.stock) cart[p.id] = (cart[p.id] ?: 0) + 1
                                        }) { Text("+") }
                                    }
                                }
                            }
                        }
                        HorizontalDivider()
                        Text("Total: $total FCFA", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(customer, { customer = it }, label = { Text("Nome completo") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(phone, { phone = it }, label = { Text("Telefone") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                        OutlinedTextField(address, { address = it }, label = { Text("Morada / local de entrega") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (cart.isEmpty()) notice = "Adiciona pelo menos um produto."
                                else if (customer.isBlank() || phone.isBlank() || address.isBlank()) notice = "Preenche o nome, telefone e local de entrega."
                                else {
                                    val summary = products.filter { (cart[it.id] ?: 0) > 0 }
                                        .joinToString { "${it.name} x${cart[it.id]}" }
                                    orders.add(Order(orders.size + 1, customer, phone, address, summary, total))
                                    products.indices.forEach { idx ->
                                        val p = products[idx]
                                        val qty = cart[p.id] ?: 0
                                        if (qty > 0) products[idx] = p.copy(stock = (p.stock - qty).coerceAtLeast(0))
                                    }
                                    cart.clear()
                                    notice = "Encomenda registada! Pagamento na entrega."
                                    page = "Encomendas"
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Ink)
                        ) { Text("Confirmar encomenda · pagar na entrega") }
                    }
                    "Encomendas" -> {
                        Text("ENCOMENDAS", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("Pagamento na entrega · ${orders.size} pedido(s)")
                        Spacer(Modifier.height(12.dp))
                        if (orders.isEmpty()) Text("Ainda não há encomendas.")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(orders) { order ->
                                Card {
                                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("Encomenda #${order.id} · ${order.status}", fontWeight = FontWeight.Bold)
                                        Text(order.customer)
                                        Text("Tel.: ${order.phone}")
                                        Text(order.address)
                                        Text(order.items)
                                        Text("Total: ${order.total} FCFA", fontWeight = FontWeight.Bold)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            TextButton(onClick = { order.status = "Confirmada"; notice = "Estado atualizado." }) { Text("Confirmar") }
                                            TextButton(onClick = { order.status = "Entregue / pago"; notice = "Entrega marcada como concluída." }) { Text("Entregue") }
                                            TextButton(onClick = { order.status = "Cancelada"; notice = "Encomenda cancelada." }) { Text("Cancelar") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("PAINEL DO ADMINISTRADOR", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("Protótipo inicial: adicionar produtos ao catálogo.")
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(newName, { newName = it }, label = { Text("Nome do produto") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(newCategory, { newCategory = it }, label = { Text("Categoria") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(newPrice, { newPrice = it }, label = { Text("Preço em FCFA") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        OutlinedTextField(newSizes, { newSizes = it }, label = { Text("Tamanhos disponíveis") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                val price = newPrice.toIntOrNull()
                                if (newName.isBlank() || price == null || price <= 0) {
                                    notice = "Indica o nome e um preço válido."
                                } else {
                                    products.add(Product((products.maxOfOrNull { it.id } ?: 0) + 1, newName.trim(), newCategory.trim(), price, newSizes.trim(), 10))
                                    newName = ""; newPrice = ""
                                    notice = "Produto adicionado. Stock inicial: 10."
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Ink)
                        ) { Text("Adicionar produto") }
                        Spacer(Modifier.height(12.dp))
                        Text("Produtos atuais: ${products.size}")
                        Text("Nota: esta versão ainda não protege a área de administrador com palavra-passe.")
                    }
                }
            }
        }
    }
}
